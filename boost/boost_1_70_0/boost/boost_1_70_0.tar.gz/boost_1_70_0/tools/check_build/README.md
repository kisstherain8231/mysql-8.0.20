# check_build

A utility submodule that, for each buildable Boost library, creates a test that builds the library.
